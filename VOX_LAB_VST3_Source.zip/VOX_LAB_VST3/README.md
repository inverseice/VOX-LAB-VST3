# VOX LAB — VST3 Vocal Suite (starter build)

A JUCE-based Windows VST3 vocal processor project with 12 starting presets and one-page controls.

## Included processing
- Input/output gain
- Low-cut cleanup
- Presence and air tone controls
- Lightweight de-essing approximation
- Vocal-style compression approximation
- Saturation
- Reverb
- Stereo delay
- Stereo width
- Presets: Studio Clean, Modern Pop, Rap Punch, Trap Lead, Hyperpop Texture,
  Dreamy, Dark R&B, Aggressive, Bright Air, Radio/Lo-Fi, Ambient, Wide Vocal

## Important limitations
This is a **starter plugin source project**, not a compiled/validated VST3 binary.
It does not yet include true automatic pitch correction / key-scale tuning.
The current de-esser, compressor, EQ voicing and output protection are deliberately
simple first-pass DSP implementations; they need listening tests and refinement before
being relied on for release-quality mastering or commercial use. Presets are starting
points and should be adjusted to the singer, microphone and recording.

## Build on Windows
1. Install Visual Studio 2022 with **Desktop development with C++**.
2. Download JUCE 7 or JUCE 8 from https://juce.com/get-juce/ and extract it.
3. Open PowerShell in this folder and run (replace the JUCE path):
   ```
   cmake -S . -B build -DJUCE_DIR="C:/JUCE"
   cmake --build build --config Release
   ```
4. CMake builds the VST3 target. The build output is typically under
   `build/VOX_LAB_artefacts/Release/VST3/VOX LAB.vst3`.
5. In FL Studio, open **Options > Manage plugins**, add/rescan the VST3 location,
   then load **VOX LAB** on a vocal mixer insert.

## Notes
- This project uses JUCE's CMake integration and JUCE modules.
- The project is stereo-in/stereo-out.
- Always test at low monitor volume first. Avoid clipping the input.
- For a finished second version, add real pitch correction with key/scale selection,
  proper multiband de-essing, oversampled saturation, a true limiter, and preset
  audition/management.
