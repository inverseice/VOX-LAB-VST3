#include "PluginEditor.h"

VoxLabAudioProcessorEditor::VoxLabAudioProcessorEditor(VoxLabAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(760, 520);
    title.setText("VOX LAB", juce::dontSendNotification);
    title.setFont(juce::Font(juce::FontOptions(30.0f, juce::Font::bold)));
    title.setColour(juce::Label::textColourId, juce::Colour(0xfff2f4ff));
    addAndMakeVisible(title);

    subtitle.setText("VOCAL ENGINE  /  ALL-IN-ONE PROCESSING", juce::dontSendNotification);
    subtitle.setFont(juce::Font(juce::FontOptions(11.0f)));
    subtitle.setColour(juce::Label::textColourId, juce::Colour(0xff9ba3bb));
    addAndMakeVisible(subtitle);

    presetBox.addItemList({"Studio Clean", "Modern Pop", "Rap Punch", "Trap Lead",
        "Hyperpop Texture", "Dreamy", "Dark R&B", "Aggressive", "Bright Air",
        "Radio / Lo-Fi", "Ambient", "Wide Vocal"}, 1);
    presetBox.setSelectedId(1, juce::dontSendNotification);
    presetBox.onChange = [this] { processor.loadPreset(presetBox.getSelectedId() - 1); };
    presetBox.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff242a3b));
    presetBox.setColour(juce::ComboBox::textColourId, juce::Colours::white);
    addAndMakeVisible(presetBox);

    addKnob("input", "INPUT");
    addKnob("highpass", "LOW CUT");
    addKnob("presence", "PRESENCE");
    addKnob("air", "AIR");
    addKnob("deess", "DE-ESS");
    addKnob("compress", "COMPRESS");
    addKnob("drive", "SATURATION");
    addKnob("reverb", "REVERB");
    addKnob("delay", "DELAY");
    addKnob("width", "WIDTH");
    addKnob("output", "OUTPUT");
}

void VoxLabAudioProcessorEditor::addKnob(const juce::String& id, const juce::String& name)
{
    auto k = std::make_unique<Knob>();
    k->slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    k->slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 66, 20);
    k->slider.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xff8de6c0));
    k->slider.setColour(juce::Slider::thumbColourId, juce::Colour(0xfff2f4ff));
    k->slider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    k->slider.setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff242a3b));
    k->label.setText(name, juce::dontSendNotification);
    k->label.setJustificationType(juce::Justification::centred);
    k->label.setColour(juce::Label::textColourId, juce::Colour(0xffb8c0d8));
    k->label.setFont(juce::Font(juce::FontOptions(10.0f, juce::Font::bold)));
    k->attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor.parameters, id, k->slider);
    addAndMakeVisible(k->slider);
    addAndMakeVisible(k->label);
    knobs.push_back(std::move(k));
}

void VoxLabAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff111521));
    g.setColour(juce::Colour(0xff1c2232));
    g.fillRoundedRectangle(getLocalBounds().toFloat().reduced(14.0f), 16.0f);
    g.setColour(juce::Colour(0xff8de6c0));
    g.fillRoundedRectangle(28.0f, 28.0f, 4.0f, 42.0f, 2.0f);
    g.setColour(juce::Colour(0xff30394d));
    g.drawRoundedRectangle(28.0f, 110.0f, 704.0f, 370.0f, 12.0f, 1.0f);
    g.setColour(juce::Colour(0xff8de6c0));
    g.setFont(juce::Font(juce::FontOptions(10.0f, juce::Font::bold)));
    g.drawText("VOCAL CHAIN  •  EQ  /  DYNAMICS  /  TONE  /  SPACE",
               42, 122, 660, 20, juce::Justification::left);
}

void VoxLabAudioProcessorEditor::resized()
{
    title.setBounds(42, 26, 250, 40);
    subtitle.setBounds(44, 66, 350, 20);
    presetBox.setBounds(500, 40, 200, 34);
    const int left = 42, top = 160, cellW = 112, cellH = 145, gap = 8;
    for (size_t i = 0; i < knobs.size(); ++i)
    {
        const int col = (int)(i % 6);
        const int row = (int)(i / 6);
        const int x = left + col * (cellW + gap);
        const int y = top + row * (cellH + 16);
        knobs[i]->label.setBounds(x, y, cellW, 20);
        knobs[i]->slider.setBounds(x + 5, y + 20, cellW - 10, 112);
    }
}
