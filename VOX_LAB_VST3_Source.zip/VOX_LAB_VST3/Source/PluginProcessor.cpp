#include "PluginProcessor.h"
#include "PluginEditor.h"

static juce::AudioParameterFloat* floatParam(const juce::String& id, const juce::String& name,
    float min, float max, float def, const juce::String& unit = {})
{
    return new juce::AudioParameterFloat(juce::ParameterID{id, 1}, name,
        juce::NormalisableRange<float>(min, max), def, unit);
}

juce::AudioProcessorValueTreeState::ParameterLayout VoxLabAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    p.add(floatParam("input", "Input", -18.0f, 18.0f, 0.0f, " dB"));
    p.add(floatParam("highpass", "Low Cut", 20.0f, 250.0f, 80.0f, " Hz"));
    p.add(floatParam("presence", "Presence", -12.0f, 12.0f, 1.5f, " dB"));
    p.add(floatParam("air", "Air", -12.0f, 12.0f, 2.0f, " dB"));
    p.add(floatParam("deess", "De-Esser", 0.0f, 100.0f, 25.0f, "%"));
    p.add(floatParam("compress", "Compression", 0.0f, 100.0f, 45.0f, "%"));
    p.add(floatParam("drive", "Saturation", 0.0f, 100.0f, 12.0f, "%"));
    p.add(floatParam("reverb", "Reverb", 0.0f, 100.0f, 12.0f, "%"));
    p.add(floatParam("delay", "Delay", 0.0f, 100.0f, 8.0f, "%"));
    p.add(floatParam("width", "Width", 0.0f, 100.0f, 50.0f, "%"));
    p.add(floatParam("output", "Output", -18.0f, 6.0f, 0.0f, " dB"));
    return p;
}

VoxLabAudioProcessor::VoxLabAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "VOXLAB", createParameterLayout())
{
}

float VoxLabAudioProcessor::get(const char* id) const
{
    return parameters.getRawParameterValue(id)->load();
}

void VoxLabAudioProcessor::prepareToPlay(double sr, int samplesPerBlock)
{
    currentSampleRate = sr;
    reverb.reset();
    reverbParams.roomSize = 0.55f;
    reverbParams.damping = 0.45f;
    reverbParams.wetLevel = 0.0f;
    reverbParams.dryLevel = 1.0f;
    reverbParams.width = 1.0f;
    reverb.setParameters(reverbParams);
    delayBuffer.setSize(2, juce::jmax(1, (int)(sr * 1.5)));
    delayBuffer.clear();
    delayWritePosition = 0;
    envelope = 0.0f;
    outputGain.reset(sr, 0.05);
    outputGain.setCurrentAndTargetValue(1.0f);
}

void VoxLabAudioProcessor::releaseResources() {}

bool VoxLabAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainInputChannelSet() == juce::AudioChannelSet::stereo()
        && layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void VoxLabAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    const float inGain = juce::Decibels::decibelsToGain(get("input"));
    const float outGain = juce::Decibels::decibelsToGain(get("output"));
    const float comp = get("compress") / 100.0f;
    const float drive = get("drive") / 100.0f;
    const float verb = get("reverb") / 100.0f;
    const float del = get("delay") / 100.0f;
    const float deess = get("deess") / 100.0f;
    const float width = get("width") / 100.0f;
    const float hp = get("highpass");
    const float presence = get("presence") / 12.0f;
    const float air = get("air") / 12.0f;

    const float hpCoeff = std::exp(-juce::MathConstants<float>::twoPi * hp / (float)currentSampleRate);
    const float smooth = std::exp(-1.0f / (0.012f * (float)currentSampleRate));
    const int delaySamples = juce::jlimit(1, delayBuffer.getNumSamples() - 1,
        (int)(currentSampleRate * (0.18 + 0.32 * del)));
    const float feedback = 0.12f + del * 0.28f;

    reverbParams.wetLevel = verb * 0.42f;
    reverbParams.dryLevel = 1.0f - verb * 0.22f;
    reverbParams.roomSize = 0.35f + verb * 0.55f;
    reverb.setParameters(reverbParams);

    for (int i = 0; i < n; ++i)
    {
        float l = buffer.getSample(0, i) * inGain;
        float r = buffer.getSample(1, i) * inGain;
        const float mono = 0.5f * (l + r);
        const float peak = std::abs(mono);
        envelope = smooth * envelope + (1.0f - smooth) * peak;

        // Gentle vocal-style compression; threshold and ratio increase with the control.
        const float threshold = 0.72f - comp * 0.48f;
        float reduction = 1.0f;
        if (envelope > threshold)
        {
            const float over = envelope - threshold;
            reduction = 1.0f / (1.0f + over * (1.0f + comp * 7.0f));
        }
        l *= reduction;
        r *= reduction;

        // Simple low-frequency cleanup and broad presence/air shaping.
        static thread_local float hpL = 0.0f, hpR = 0.0f, prevL = 0.0f, prevR = 0.0f;
        hpL = hpCoeff * (hpL + l - prevL); hpR = hpCoeff * (hpR + r - prevR);
        prevL = l; prevR = r;
        l = hpL; r = hpR;

        const float bright = (l - 0.985f * prevL) * presence * 0.10f;
        const float airy = (l - 0.995f * prevL) * air * 0.08f;
        l += bright + airy;
        r += (r - 0.985f * prevR) * presence * 0.10f + (r - 0.995f * prevR) * air * 0.08f;

        // Lightweight de-essing approximation: dynamically soften sharp high-frequency peaks.
        const float highL = l - 0.92f * prevL;
        const float highR = r - 0.92f * prevR;
        const float ess = juce::jmax(std::abs(highL), std::abs(highR));
        const float essGain = 1.0f - deess * 0.006f * juce::jlimit(0.0f, 1.0f, ess * 4.0f);
        l *= essGain; r *= essGain;

        if (drive > 0.001f)
        {
            const float amount = 1.0f + drive * 5.0f;
            l = std::tanh(l * amount) / std::tanh(amount);
            r = std::tanh(r * amount) / std::tanh(amount);
        }

        // Stereo delay.
        const int readPos = (delayWritePosition - delaySamples + delayBuffer.getNumSamples()) % delayBuffer.getNumSamples();
        const float dl = delayBuffer.getSample(0, readPos);
        const float dr = delayBuffer.getSample(1, readPos);
        delayBuffer.setSample(0, delayWritePosition, l + dl * feedback);
        delayBuffer.setSample(1, delayWritePosition, r + dr * feedback);
        l += dl * del * 0.48f;
        r += dr * del * 0.48f;
        delayWritePosition = (delayWritePosition + 1) % delayBuffer.getNumSamples();

        // Width via mid/side.
        const float mid = 0.5f * (l + r);
        const float side = 0.5f * (l - r) * (width * 2.0f);
        l = mid + side; r = mid - side;

        buffer.setSample(0, i, l);
        buffer.setSample(1, i, r);
    }

    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::ProcessContextReplacing<float> context(block);
    reverb.process(context);

    for (int i = 0; i < n; ++i)
    {
        const float l = buffer.getSample(0, i) * outGain;
        const float r = buffer.getSample(1, i) * outGain;
        buffer.setSample(0, i, juce::jlimit(-0.98f, 0.98f, l));
        buffer.setSample(1, i, juce::jlimit(-0.98f, 0.98f, r));
    }
}

void VoxLabAudioProcessor::loadPreset(int idx)
{
    struct Preset { float hp, pres, air, ds, comp, drive, rev, delay, width, out; };
    static const Preset presets[] = {
        {80, 1.5f, 2.0f, 25, 45, 12, 12, 8, 50, 0},    // Studio Clean
        {95, 3.0f, 4.0f, 38, 58, 10, 18, 10, 65, -1},  // Modern Pop
        {105, 2.5f, 1.0f, 42, 72, 24, 8, 14, 55, -2},  // Rap Punch
        {110, 3.5f, 3.0f, 45, 78, 42, 10, 22, 75, -3},// Trap Lead
        {120, 5.0f, 6.0f, 55, 65, 58, 28, 35, 90, -4},// Hyperpop Texture
        {75, 1.0f, 3.0f, 30, 52, 8, 32, 24, 80, -1},  // Dreamy
        {70, -1.5f, 1.0f, 28, 62, 20, 18, 12, 45, -2},// Dark R&B
        {100, 0.0f, 0.0f, 50, 82, 48, 5, 8, 40, -3},   // Aggressive
        {90, 2.0f, 5.0f, 35, 48, 14, 10, 12, 70, -1},  // Bright Air
        {140, -2.0f, -1.0f, 65, 70, 65, 8, 18, 60, -5},// Radio/Lo-Fi
        {65, 1.5f, 4.5f, 32, 42, 5, 48, 40, 100, -2},  // Ambient
        {85, 2.0f, 2.0f, 40, 60, 30, 22, 28, 85, -2}   // Wide Vocal
    };
    const auto& p = presets[juce::jlimit(0, 11, idx)];
    auto set = [this](const char* id, float value) {
        if (auto* param = parameters.getParameter(id))
            param->setValueNotifyingHost(param->convertTo0to1(value));
    };
    set("highpass", p.hp); set("presence", p.pres); set("air", p.air);
    set("deess", p.ds); set("compress", p.comp); set("drive", p.drive);
    set("reverb", p.rev); set("delay", p.delay); set("width", p.width); set("output", p.out);
}

void VoxLabAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, dest);
}
void VoxLabAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessorEditor* VoxLabAudioProcessor::createEditor()
{
    return new VoxLabAudioProcessorEditor(*this);
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VoxLabAudioProcessor();
}
