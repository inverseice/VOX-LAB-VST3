#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class VoxLabAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit VoxLabAudioProcessorEditor(VoxLabAudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    VoxLabAudioProcessor& processor;
    juce::ComboBox presetBox;
    juce::Label title, subtitle;
    struct Knob {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
    };
    std::vector<std::unique_ptr<Knob>> knobs;
    void addKnob(const juce::String& id, const juce::String& name);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VoxLabAudioProcessorEditor)
};
